const byte RELAY_PIN = 9;   // modulo relè
const byte FAN_PWM   = 10;  // transistor in PWM

void setup() {
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(FAN_PWM,   OUTPUT);
  digitalWrite(RELAY_PIN, LOW); // relè spento (dipende se è active low)
  analogWrite(FAN_PWM, 0);      // ventola spenta
  Serial1.begin(9600);
  Serial.begin(115200);
}

void loop() {
  if (Serial1.available()) {
    String cmd = Serial1.readStringUntil('\n');
    cmd.trim();
    Serial.print("BT-> "); Serial.println(cmd);

    if (cmd == "ON") {
      digitalWrite(RELAY_PIN, HIGH);  // o LOW se il modulo è active-low
      analogWrite(FAN_PWM, 255);
      Serial1.println("OK ON");
    }
    else if (cmd == "OFF") {
      analogWrite(FAN_PWM, 0);
      digitalWrite(RELAY_PIN, LOW);   // spegni anche la 9 V
      Serial1.println("OK OFF");
    }
    else if (cmd.startsWith("T")) {
      int v = cmd.substring(1).toInt();
      if (v < 0) v = 0;
      if (v > 255) v = 255;

      if (v == 0) {
        analogWrite(FAN_PWM, 0);
        digitalWrite(RELAY_PIN, LOW); // niente velocità → spegni relè
      } else {
        digitalWrite(RELAY_PIN, HIGH); // alimenta la 9 V
        analogWrite(FAN_PWM, v);       // regola velocità
      }
      Serial1.println("OK T");
    }
  }
}
