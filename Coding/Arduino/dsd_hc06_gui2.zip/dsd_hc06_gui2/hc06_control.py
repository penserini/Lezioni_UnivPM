import serial
import time

COM_PORT = "COM5"   # <-- cambia con la tua porta
BAUD = 9600

def send(cmd):
    with serial.Serial(COM_PORT, BAUD, timeout=2) as ser:
        # Piccola attesa per stabilizzare la seriale
        time.sleep(0.2)
        ser.write((cmd + "\n").encode("utf-8"))
        # Legge eventuale risposta
        reply = ser.readline().decode(errors="ignore").strip()
        print("RX:", reply)

if __name__ == "__main__":
    # Accendi
    send("ON")
    time.sleep(3)

    # Metti al 50% (se FAN_PIN è su un pin PWM)
    send("T128")
    time.sleep(3)

    # Spegni
    send("OFF")
