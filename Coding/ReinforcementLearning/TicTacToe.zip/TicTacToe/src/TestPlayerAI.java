
public class TestPlayerAI {

	public TestPlayerAI() {
		
		
		int[][] statoBoard = new int[3][3];		
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		statoBoard[1][0] = -1;
		statoBoard[1][1] = 1;
		statoBoard[1][2] = -1;
		statoBoard[2][0] = 0;
		statoBoard[2][1] = 1;
		statoBoard[2][2] = -1;
		
		PlayerAI playerAI = new PlayerAI(statoBoard,1);
		
		
		/*
		int[][] statoBoard = new int[3][3];		
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		statoBoard[1][0] = -1;
		statoBoard[1][1] = 1;
		statoBoard[1][2] = -1;
		statoBoard[2][0] = -1;
		statoBoard[2][1] = 1;
		statoBoard[2][2] = -1;
		
		PlayerAI playerAI = new PlayerAI(statoBoard,0);
		*/
		
		/*
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		statoBoard[1][0] = 1;
		statoBoard[1][1] = 1;
		statoBoard[1][2] = -1;
		statoBoard[2][0] = 0;
		statoBoard[2][1] = 1;
		statoBoard[2][2] = -1;		
		
		PlayerAI playerAI = new PlayerAI(statoBoard,0);
		*/
		
		/*
		//MOSSA = {{0,0,1},{0,1,1},{0,1,-1}};
		statoBoard = new int[3][3];		
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		statoBoard[1][0] = 0;//1° possibile mossa di O dopo quella di X
		statoBoard[1][1] = 1;
		statoBoard[1][2] = 1;
		statoBoard[2][0] = 0;
		statoBoard[2][1] = 1;
		statoBoard[2][2] = -1;*/
		
		
	}

	public static void main(String[] args) {
		new TestPlayerAI();

	}

}
