
public class TestLista {
	private Lista lista;
	private eleLista newElementoL = null;
	private int[][] statoBoard = null;

	public TestLista() {
		statoBoard = new int[3][3];
		int[][] statoBoard = {{0,0,0},{0,0,0},{0,0,0}};
		/*
		 * La lista si crea fornendo uno stato della Scacchiera/Board
		 * e associandolo al primo elemento ("testa")
		 */
		lista = new Lista(statoBoard);//creo la lista
				
		//statoBoard = {{1,0,0},{0,0,0},{0,0,0}};
		statoBoard[0][0] = 1;
		newElementoL = new eleLista(statoBoard,lista,true);
		lista.addElementoLista(newElementoL);
						
		//statoBoard = {{0,1,0},{0,0,0},{0,0,0}};
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 1;
		newElementoL = new eleLista(statoBoard,lista);
		lista.addElementoLista(newElementoL);
						
		//statoBoard = {{0,0,1},{0,0,0},{0,0,0}};
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		newElementoL = new eleLista(statoBoard,lista);
		lista.addElementoLista(newElementoL);	
	}

	public static void main(String[] args) {
		new TestLista();
	}

}
