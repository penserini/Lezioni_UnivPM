import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;

public class SimpleDeepCopy {
	
	/**
     * Returns a copy of the object, or null if the object cannot
     * be serialized.
     */
    public static Object copy(Object orig) {
        Object obj = null;
        try {
            // Write the object out to a byte array
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream out = new ObjectOutputStream(bos);
            out.writeObject(orig);
            out.flush();
            out.close();

            // Make an input stream from the byte array and read
            // a copy of the object back in.
            ObjectInputStream in = new ObjectInputStream(
                new ByteArrayInputStream(bos.toByteArray()));
            obj = in.readObject();
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        catch(ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        }
        return obj;
    }
  
	public SimpleDeepCopy() {
		/*
		int[][] statoBoard = new int[3][3];		
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		statoBoard[1][0] = -1;
		statoBoard[1][1] = 1;
		statoBoard[1][2] = -1;
		statoBoard[2][0] = 0;
		statoBoard[2][1] = 1;
		statoBoard[2][2] = -1;
		
		int[][] statoBoard2 = new int[3][3];
		
		statoBoard2 = (int[][])this.copy(statoBoard);
		statoBoard2[1][0] = 1;
		*/
	}

	public static void main(String[] args) {
		new SimpleDeepCopy();

	}

}
