import java.util.Vector;
import java.util.Random;

public class PlayerAI {
	private AlberoN mossaIA = null;
	private AlberoN alberoMosse = null;
	private Random random = null;
	private SimpleDeepCopy deepCopy = new SimpleDeepCopy();
	private boolean boardFull = true; //non ci sono più mosse possibli (nodo foglia)	
	private int valPatta = 0; 
	private int valWin_O = 1;
	private int valWin_X = -1;
	private int player_O = 0; 
	private int player_1 = 1; 
	private int[][] mossaSceltaAI; // contiene tutta la scacchiera, inclusa la nuova mossa di AI
	private int[] giocataAI = new int[2]; // contiene solo la RIGA e la COLONNA della giocata
	
    /*
     * player è X --> 1 (O --> 0)
     */
	public PlayerAI(int[][] statoBoard, int player) {
		alberoMosse = new AlberoN(statoBoard);//crea root node
		alberoMosse.getNodoRoot().getFirstEleL().setValEuristica(2);//Val iniziale euristica eleRoot
		
		this.creaAlberoMosse(alberoMosse.getNodoRoot(),alberoMosse.getNodoRoot().getFirstEleL(), statoBoard, player);
		
		/*
		 * COSTRUIRE QUI UNA CHIAMATA AD UN METODO CHE RICAVA LA MOSSA MIGLIORE DA RESTITUIRE A "MainGUI"
		 */
		System.out.println("Valore euristica per root: " + alberoMosse.getNodoRoot().getFirstEleL().getValEuristica());
		
		if(alberoMosse.getNodoRoot().getFirstEleL().getNodoListaSucc() != null) {
			// "creaMossaAI" trova la mossa e la posizione in "this.mossaSceltaAI"
			this.creaMossaAI(alberoMosse.getNodoRoot().getFirstEleL().getNodoListaSucc(), alberoMosse.getNodoRoot().getFirstEleL().getValEuristica());
		}
		
		/*
		if(this.mossaSceltaAI != null || this.boardFull(statoBoard)) {
			if(alberoMosse.checkWinner(this.mossaSceltaAI)){
				System.out.println("WINNER");
					System.out.println("Player = O --> WINNER");
					
				}else if(player == 1) {
					System.out.println("Player = X --> WINNER");
					
				}
				this.stampaBoard(this.mossaSceltaAI);
				return;
			}if(this.boardFull(statoBoard)) {
				System.out.println("Tie break --> PATTA");			
				this.stampaBoard(this.mossaSceltaAI);
				
				return;
			}
		}
		*/
				
	}
	
	/*
	 * Questo metodo viene chiamato passando il nodoL con la mossa scelta dall'AI 
	 * attraverso il valore di "valEuristica"
	 */
	private void creaMossaAI(Lista nodoL, int valEuristica) {
		eleLista currentEleL = nodoL.getFirstEleL();
		while(currentEleL.getValEuristica() != valEuristica && currentEleL.succL != null) {//il 2° confronto non serve
			currentEleL = currentEleL.succL;
		}
		this.setMossaAI(currentEleL.getStatoBoard());
		giocataAI = calcolaGiocataAI(nodoL.getEleTestaLista().getStatoBoard(),currentEleL.getStatoBoard());
	}
	
	private int[] calcolaGiocataAI(int[][] initialBoard, int[][] mossaAI) {
		int[] valori = new int[2];
		for (int r = 0; r < mossaAI.length; r++) {
	         for (int c = 0; c < mossaAI.length; c++) {
	        	 if(initialBoard[r][c] != mossaAI[r][c]) {
	        		 valori[0] = r;
	        		 valori[1] = c;
	        		 return valori;
	        	 }
	         }
	     }		
		return valori;
	}
	

	
	private void setMossaAI(int[][] statoBoard) {
		this.mossaSceltaAI = statoBoard;
	}
	
	public int[][] getMossaAI() {
		return this.mossaSceltaAI;
	}
	
	public int[] getGiocataAI() {
		return this.giocataAI;
	}
	
	/*
	 * Crea l'albero delle possibili mosse a partire dalla scacchiera iniziale "statoBoard"
	 * e dal giocatore che deve fare la mossa "player"
	 */
	private void creaAlberoMosse(Lista nodoL, eleLista eleL, int[][] statoBoard,int player){
		int[][] mossa = new int[3][3];
		
		/*
		 * PRIMA SI SPOSTA IN PROFONDITA'
		 */
		//if(alberoMosse.checkWinner(statoBoard) || this.boardFull(statoBoard)) {
		if(alberoMosse.checkWinner(statoBoard)){
			System.out.println("WINNER");
			if(player == 0) {
				System.out.println("Player = X --> +1");
				eleL.setValEuristica(+1);
			}else if(player == 1) {
				System.out.println("Player = O --> -1");
				eleL.setValEuristica(-1);
			}
			this.stampaBoard(statoBoard);
			return;
		}if(this.boardFull(statoBoard)) {
			System.out.println("Tie break --> 0");			
			this.stampaBoard(statoBoard);
			eleL.setValEuristica(0);
			return;
		}
						
		if(player == 1) {
			//MUOVE IN PROFONDITA'
			/*
			 * "faiMossa" genera tutte le mosse di un particolare nodoLista e 
			 * rimuove dalla lista la mossa che restituisce "mossa" 
			 */
			mossa = faiMossa(nodoL,statoBoard,player_1);				
			alberoMosse.addMossaNodoPreciso(eleL, mossa);			
			this.creaAlberoMosse(eleL.getNodoListaSucc(),eleL.getNodoListaSucc().getFirstEleL(),mossa,player_O);	
		}
		
		if(player == 0) {
			//MUOVE IN PROFONDITA'
			/*
			 * "faiMossa" genera una lista (Vector) con tutte le mosse di un particolare nodoLista e 
			 * rimuove dalla lista la mossa che restituisce "mossa" 
			 */
			mossa = faiMossa(nodoL,statoBoard,player_O);				
			alberoMosse.addMossaNodoPreciso(eleL, mossa);			
			this.creaAlberoMosse(eleL.getNodoListaSucc(),eleL.getNodoListaSucc().getFirstEleL(),mossa,player_1);		
		}
		
		//AMPIEZZA
		/*
		 * si deve prendere la lista delle mosse del nodoLista corrente, precedentemente creata, 
		 * e selezionare una mossa rimuovendola poi dalla lista stessa
		 */		
		while(nodoL.EsisteMossa()) {
			mossa = prendiMossa(nodoL);
			eleLista newEleLista = alberoMosse.addEleLista(eleL.getNodoListaSucc(), mossa);
			
			if(player==0) this.creaAlberoMosse(eleL.getNodoListaSucc(),newEleLista,mossa,player_1);
			if(player==1) this.creaAlberoMosse(eleL.getNodoListaSucc(),newEleLista,mossa,player_O);
		}
		
		/*
		 * PROPAGAZIONE DELL'EURISTICA DALLE FOGLIE ALLA ROOT
		 * ricordiamoci che quando gioca palyer_1 --> massimizza 
		 * e quando gioca player_O --> minimizza, i valori della
		 * euristica precedentemente calcolati nel nodoL successivo
		 */
		if(!nodoL.EsisteMossa() && player == 1) {		

			//System.out.println("Val euristica: "+this.minmaxVal(eleL, "max"));
			eleL.setValEuristica(this.minmaxVal(eleL, "max"));
			//this.stampaBoard(eleL.getStatoBoard());
			
		}else if(!nodoL.EsisteMossa() && player == 0) {

			//System.out.println("Val euristica: "+this.minmaxVal(eleL, "min"));
			eleL.setValEuristica(this.minmaxVal(eleL, "min"));
			//this.stampaBoard(eleL.getStatoBoard());

		}
	}
	//*****************************************************************************************************
	
	
	public int minmaxVal(eleLista eleL, String minmax) {
		Lista succNodoL = eleL.getNodoListaSucc();//NodoL o contenitore a cui punta "eleL"
		eleLista currentEleL = succNodoL.getFirstEleL();
		//eleLista currentEleL = succNodoL.getEleTestaLista();
		
		if(minmax.equals("max")) {
			int max = currentEleL.getValEuristica();
			while(currentEleL.succL != null) {
				if(max < currentEleL.succL.getValEuristica()) {
					max = currentEleL.succL.getValEuristica();					
				}
				currentEleL = currentEleL.succL;				
			}
			return max;
			
		}else if(minmax.equals("min")) {
			int min = currentEleL.getValEuristica();
			while(currentEleL.succL != null) {
				if(min > currentEleL.succL.getValEuristica()) {
					min = currentEleL.succL.getValEuristica();					
				}
				currentEleL = currentEleL.succL;
			}
			return min;
		}		
		return 2;//Codice ERRORE: qui non ci deve mai arrivare
	}
	
	
	public void stampaBoard(int[][] statoBoard) {
		 System.out.println("");
	     for (int r = 0; r < statoBoard.length; r++) {
	         for (int c = 0; c < statoBoard.length; c++) {
	        	 if(statoBoard[r][c] == 0) {
	        		 System.out.print("O");
		        	 System.out.print(" ");
	        	 }else if(statoBoard[r][c] == 1) {
	        		 System.out.print("X");
		        	 System.out.print(" ");
	        	 }else if(statoBoard[r][c] == -1) {
	        		 System.out.print(" ");
		        	 System.out.print(" ");
	        	 }	        	 	        	    
	         }
	         System.out.println("");
	     }
	     System.out.println("");
	     System.out.println("");
	}
	
	
	public boolean boardFull(int[][] Board) {		
	     for (int r = 0; r < Board.length; r++) {
	         for (int c = 0; c < Board.length; c++) {
	        	 
	        	 if(Board[r][c] == -1) {
	        		 return false;	
	        	 }
	         }
	     }
		return true;
	}
	
	/*
	 * Serve a prendere una mossa dalla lista di mosse associata al nodoL
	 * la mossa viene presa in modalità casuale
	 */
	private int[][] prendiMossa(Lista nodoL) {
		int[][] statoBoardNew = new int[3][3];		
		 this.boardFull = true;	 
	

	     if(nodoL.getSizeVectMosseFatte() > 0) {
		     random = new Random();
		     // genera numero casuale tra 0 e (vect.lenght()-1)
		     int number = random.nextInt(nodoL.getSizeVectMosseFatte());//tiene già conto che parte da zero, per cui toglie -1	    
		     statoBoardNew = nodoL.getVectMosseFatte().elementAt(number);
		     	     
		     /*
		      * Aggiorna il nodo lista (nodoL) dell'albero delle mosse, 
		      * "vect" contiene le mosse (elementi di nodoL) ancora da creare
		      */
		     nodoL.getVectMosseFatte().remove(number);
		     
		     return statoBoardNew;
	     }
		
		return null;
	}
	
	private int[][] faiMossa(Lista nodoL, int[][] statoBoard, int player) {
		int[][] statoBoardNew = new int[statoBoard.length][statoBoard.length];		
		 this.boardFull = true;	 
	
	     for (int r = 0; r < statoBoard.length; r++) {
	         for (int c = 0; c < statoBoard.length; c++) {
	        	 
	        	 if(statoBoard[r][c] == -1) {
	        		 int[][] Board = new int[statoBoard.length][statoBoard.length];	        		 
	        		 //int[][] Board = (int[][])statoBoard.clone();
	        		 Board = (int[][])deepCopy.copy(statoBoard);
        		 
	        		 Board[r][c] = player;
	        		 nodoL.addMossaBoard(Board);//aggiungo le potenziali mosse per ogni nodoL
	        		 //statoBoard[r][c] = -1;
	        		 
	        		 this.boardFull = false;//esistono ancora mosse da fare
	        	 }
	         }
	     }
	     if(!this.boardFull) {
		     random = new Random();
		     // genera numero casuale tra 0 e (vect.lenght()-1)
		     int number = random.nextInt(nodoL.getSizeVectMosseFatte());//tiene già conto che parte da zero, per cui toglie -1	    
		     statoBoardNew = nodoL.getVectMosseFatte().elementAt(number);
		     	     
		     /*
		      * Aggiorna il nodo lista (nodoL) dell'albero delle mosse, 
		      * "vect" contiene le mosse (elementi di nodoL) ancora da creare
		      */
		     nodoL.getVectMosseFatte().remove(number);
		     
		     return statoBoardNew;
	     }
		
		return null;
	}
	
	/*
	 * DEPRECATED - usa un metodo risolutivo per le mosse superato ma interessante
	 */
	private int[][] faiMossaOLD(Lista nodoL, int[][] statoBoard, int player) {
		 
		 int[][] statoBoardNew = new int[statoBoard.length][statoBoard.length];
		 int[] selectedMove = new int[2];
		 this.boardFull = true;
		 
		 //Vector vect = new Vector(); --> Vector<String> myVector = new Vector<String>();
		 Vector<int[]> vect = new Vector<int[]>();
		
	     for (int r = 0; r < statoBoard.length; r++) {
	         for (int c = 0; c < statoBoard.length; c++) {
	        	 statoBoardNew[r][c] = statoBoard[r][c];
	        	 
	        	 if(statoBoard[r][c] == -1) {
	        		 int[] potentialMove = new int[2];
	        		 potentialMove[0] = r;//RIGA
	        		 potentialMove[1] = c;//COLONNA
	        		 vect.add(potentialMove);
	        		 
	        		 statoBoardNew[potentialMove[0]][potentialMove[1]] = player;
	        		 nodoL.addMossaBoard(statoBoardNew);//aggiungo le potenziali mosse per ogni nodoL
	        		 statoBoardNew[potentialMove[0]][potentialMove[1]] = -1;//ripristino i valori per "statoBoardNew"	        		 
	        		 
	        		 this.boardFull = false;//esistono ancora mosse da fare
	        	 }
	         }
	     }
	     if(!this.boardFull) {
		     random = new Random();
		     // genera numero casuale tra 0 e (vect.lenght()-1)
		     int number = random.nextInt(vect.size());//tiene già conto che parte da zero, per cui toglie -1	    
		     //selectedMove = (int[])vect.get(number);
		     selectedMove = (int[])vect.elementAt(number);
		     statoBoardNew[selectedMove[0]][selectedMove[1]] = player;
		     
		     return statoBoardNew;
	     }
		
		return null;
	}
		
}
	

