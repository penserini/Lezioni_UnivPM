/*
 * convenzione scacchiera "1" player-1 ("X"), "0" player-2 ("O") e "-1" caselle ancora da riempire
 */
public class TestAlbero {
	AlberoN alberoMosse = null;
	//int[][] statoBoard = new int[3][3];

	public TestAlbero() {
		//int[][] statoBoard = {{0,0,1},{-1,1,-1},{0,1,-1}};
		int[][] statoBoard = new int[3][3];		
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		statoBoard[1][0] = -1;
		statoBoard[1][1] = 1;
		statoBoard[1][2] = -1;
		statoBoard[2][0] = 0;
		statoBoard[2][1] = 1;
		statoBoard[2][2] = -1;
		
		
		/*
		 * crea nodoRoot dell'albero, cioè una lista di un solo elemento
		 * rappresenta lo stato della Board con il TURNO DI X (player-1)
		 */
		alberoMosse = new AlberoN(statoBoard);
		
		/*
		 * simulo le mosse di X
		 */
		//MOSSA = {{0,0,1},{-1,1,1},{0,1,-1}};
		statoBoard = new int[3][3];		
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		statoBoard[1][0] = -1;
		statoBoard[1][1] = 1;
		statoBoard[1][2] = 1;//** 1° possibile mossa per X **
		statoBoard[2][0] = 0;
		statoBoard[2][1] = 1;
		statoBoard[2][2] = -1;
		alberoMosse.addNodoAlbero(statoBoard);
		
		//MOSSA = {{0,0,1},{-1,1,-1},{0,1,1}};	
		statoBoard = new int[3][3];		
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		statoBoard[1][0] = -1;
		statoBoard[1][1] = 1;
		statoBoard[1][2] = -1;
		statoBoard[2][0] = 0;
		statoBoard[2][1] = 1;
		statoBoard[2][2] = 1;//2° possibile mossa per X
		alberoMosse.addMossaNodo(statoBoard);
		
		//MOSSA = {{0,0,1},{1,1,-1},{0,1,-1}};
		statoBoard = new int[3][3];		
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		statoBoard[1][0] = 1;//3° possibile mossa per X
		statoBoard[1][1] = 1;
		statoBoard[1][2] = -1;
		statoBoard[2][0] = 0;
		statoBoard[2][1] = 1;
		statoBoard[2][2] = -1;
		alberoMosse.addMossaNodo(statoBoard);
		
		/*
		 * simulo le mosse di O a partire dall'ultima mossa di X (vedi precedente mossa)
		 * sfrutto il fatto che il puntatore sia rimasto posizionato sull'ultimo elemento 
		 * della lista di mosse per X
		 */
		//MOSSA = {{0,0,1},{1,1,0},{0,1,-1}};
		statoBoard = new int[3][3];		
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		statoBoard[1][0] = 1;
		statoBoard[1][1] = 1;
		statoBoard[1][2] = 0;//1° possibile mossa di O dopo quella di X
		statoBoard[2][0] = 0;
		statoBoard[2][1] = 1;
		statoBoard[2][2] = -1;
		
		alberoMosse.addNodoAlbero(statoBoard);
		
		/*
		 * INSERIRE ELEMENTI IN PUNTI PRECISI DELL'ALBERO
		 */
		int[][] searchForInput = new int[3][3];
		searchForInput[0][0] = 0;
		searchForInput[0][1] = 0;
		searchForInput[0][2] = 1;
		searchForInput[1][0] = -1;
		searchForInput[1][1] = 1;
		searchForInput[1][2] = 1;
		searchForInput[2][0] = 0;
		searchForInput[2][1] = 1;
		searchForInput[2][2] = -1;
		/*
		 * Trova il nodoLista dove inserire il nuovo elemento
		 * e lo parcheggia con "setEleListaTrovato"
		 */
		alberoMosse.searchDFS(alberoMosse.getNodoRoot(), alberoMosse.getNodoRoot().getFirstEleL(),searchForInput);
		
		//MOSSA = {{0,0,1},{0,1,1},{0,1,-1}};
		statoBoard = new int[3][3];		
		statoBoard[0][0] = 0;
		statoBoard[0][1] = 0;
		statoBoard[0][2] = 1;
		statoBoard[1][0] = 0;//1° possibile mossa di O dopo quella di X
		statoBoard[1][1] = 1;
		statoBoard[1][2] = 1;
		statoBoard[2][0] = 0;
		statoBoard[2][1] = 1;
		statoBoard[2][2] = -1;
		/*
		 * Prende il nodoLista dove inserire il nuovo elemento
		 * e lo usa come puntatore per il nuovo inserimento
		 */
		alberoMosse.addMossaNodoPreciso(alberoMosse.getEleListaTrovato(), statoBoard);
		
		// ******************************************
		
		int[][] searchForBoard = new int[3][3];
		searchForBoard[0][0] = 0;
		searchForBoard[0][1] = 0;
		searchForBoard[0][2] = 1;
		searchForBoard[1][0] = -1;
		searchForBoard[1][1] = 1;
		searchForBoard[1][2] = -1;
		searchForBoard[2][0] = 0;
		searchForBoard[2][1] = 1;
		searchForBoard[2][2] = 1;
		alberoMosse.searchDFS(alberoMosse.getNodoRoot(), alberoMosse.getNodoRoot().getFirstEleL(),searchForBoard);
	    
		/*if(eleListaTrovato != null) {
	    	System.out.println("Trovato!");
	    	System.out.println("Nodo: " + eleListaTrovato);
	    }*/
		
	}
	

	
	

	public static void main(String[] args) {
		new TestAlbero();
	}

}
