/**
*
* @author  
* @version 
* N.B. Lo stato della scacchiera è il medesimo per tutti gli elementi della Lista
*/

public class eleLista {
	/*
	 * ogni elemento della lista può puntare ad un successivo nodo dell'albero (nodoLista)
	 */
	private Lista nodoListaSucc = null;
	private Lista nodoListaContenitore = null;
		
	eleLista succL;
	eleLista precL;
	private boolean inizioL = false;//testa della lista (non basta avere precL = null)
	private int[][] statoBoard = new int[3][3];
	
	private int valEuristica = 2;//valore iniziale

	/** Creates new List element */
	public eleLista() {		
	}
	
	/** Crea un nuovo elemento della lista con lo stato della scacchiera*/
	public eleLista(int[][] statoBoard, Lista nodoListaContenitore) {
		this.statoBoard = statoBoard;
		this.nodoListaContenitore = nodoListaContenitore;
	}
	
	/*
	 * Costruttore usato solo per creare il primo elemento che ha "inizioL=true"
	 */
	public eleLista(int[][] statoBoard, Lista nodoListaContenitore, boolean inizioL) {
		this.statoBoard = statoBoard;
		this.inizioL = inizioL;//boolean
		this.nodoListaContenitore = nodoListaContenitore;
	}
	
	// *************** SET METHODs *****************
	
	public void setStatoBoard(int[][] statoBoard) {
		this.statoBoard = statoBoard;
	}
	
	public void setSuccL(eleLista succL) {
		this.succL = succL;
	}
	
	public void setPrecL(eleLista precL) {
		this.precL = precL;
	}
	
	/*
	 * puntare ad un nodo successivo dell'albero (nodoListaSucc)
	 * n.b. newNodoLista ha già la Board e il nodoListaPrec
	 */
	public void setNodoListaSucc(Lista newNodoLista) {
		this.nodoListaSucc = newNodoLista;
	}
	
	public void setValEuristica(int val) {
		this.valEuristica = val;
	}
	
	// *************** GET METHODs *****************
	
	public int[][] getStatoBoard() {
		return this.statoBoard;
	}
	
	public int getValEuristica() {
		return this.valEuristica;
	}
	
	public Lista getNodoListaSucc() {
		return this.nodoListaSucc;
	}
	
	public Lista getNodoListaContenitore() {
		return this.nodoListaContenitore;
	}
	
	//***************************
	public boolean getInizioL() {
		return this.inizioL;
	}
	//***************************
	
	public eleLista getEleSuccL() {
		return this.succL;
	}
	
	public boolean equalsBoard(int[][] searchForBoard) {
		
	     for (int r = 0; r < statoBoard.length; r++) {
	         for (int c = 0; c < statoBoard.length; c++) {
	        	 if(this.statoBoard[r][c] != searchForBoard[r][c])  return false;
	         }
	     }		
		return true;
	}

}
