/**
*
* @author  
* @version 
* N.B. Lo stato della scacchiera è il medesimo per tutti gli elementi della Lista
*/
public class AlberoN {
	private Lista nodoRoot = null;
	private Lista nodoCorrente = null;
	private Lista nodoAlberoPrec = null;
	private eleLista newElementoL = null;
	private int[][] inizioBoard = new int[3][3];
	

	/*
	 * Alla creazione il nodo root contiene una lista di un solo elemento
	 * con la Board iniziale pronta per la "mossa di X"
	 */
	public AlberoN(int[][] board) {
		this.inizioBoard = board;
		this.nodoRoot = new Lista(this.inizioBoard);
		this.nodoCorrente = this.nodoRoot;
	}
	
	/*
	 * "addNodoAlbero" crea la lista che conterrà le possibili mosse per un player
	 * per es. se eseguito subito dopo la creazione del nodo root, rappresenta le 
	 * possibili mosse di X. All'inizio della creazione, la lista "newNodoAlbero",
	 * contiene solamente un elemento, cioè la prima mossa di X.	 * 
	 */
	public void addNodoAlbero(int[][] board) {
		Lista newNodoAlbero = new Lista(board);
		
		//inserire qui la modifica di NodoSuccessivo, dell'elemento lista, che punti a newNodoAlbero
		this.nodoCorrente.setNodoListaSucc(newNodoAlbero);
		
		this.nodoCorrente.addNodoLista(newNodoAlbero);
		this.nodoCorrente = newNodoAlbero;
		this.nodoAlberoPrec = this.nodoCorrente.getNodoListaPrec();
	}
	
	/*
	 * Il seguente metodo inserisce una nuova lista-nodo in un punto particolare  
	 */
	public void addMossaNodoPreciso(eleLista puntoInserimento, int[][] board) {
		Lista newNodoAlbero = new Lista(board);
		newNodoAlbero.setEleTestaLista(puntoInserimento);
		
		this.nodoCorrente = puntoInserimento.getNodoListaContenitore();//per Lista
		this.nodoCorrente.setCurrent(puntoInserimento);//per eleLista
		this.nodoCorrente.setNodoListaSucc(newNodoAlbero);
		this.nodoCorrente.addNodoLista(newNodoAlbero);
		this.nodoAlberoPrec = this.nodoCorrente.getNodoListaPrec();		
	}
	
	
	/*
	 * "addMossaNodo" aggiunge ad un nodo precedentemente creato con "addNodoAlbero"
	 * un'ulteriore possibile mossa per un determinato player.
	 * ADD DI UN ELEMENTO DELLA LISTA, CIOE' SI SPOSTA DENTRO LA LISTA	 
	 */
	public void addMossaNodo(int[][] board) {
		newElementoL = new eleLista(board, this.nodoCorrente);		
		nodoCorrente.addElementoLista(newElementoL);		
	}
	
	public void addMossaNodo(Lista nodoL, int[][] board) {
		newElementoL = new eleLista(board, nodoL);		
		nodoL.addElementoLista(newElementoL);		
	}
	
	/*
	 * *****************************************************
	 */
	public eleLista addEleL(Lista nodoL, int[][] board) {//deprecated
		newElementoL = new eleLista(board, nodoL);		
		nodoL.addElementoLista(newElementoL);
		return newElementoL;
	}
	
	/*
	 * Migliorato rispetto al precedente "addEleL"
	 */
	public eleLista addEleLista(Lista nodoL, int[][] board) {
		newElementoL = new eleLista(board, nodoL);		
		nodoL.addElLista(newElementoL);
		return newElementoL;
	}
	
	// *****************************************************
	
	/*
	 * Dato un elemento della lista (EleCorrente) e una nuova giocata 
	 */
	public void addEleLista(eleLista EleCorrente, int[][] board) {
		newElementoL = new eleLista(board, EleCorrente.getNodoListaContenitore());		
		EleCorrente.getNodoListaContenitore().addElementoLista(newElementoL);
		
		//return newElementoL;
	}
	
	public Lista getNodoRoot() {
		return this.nodoRoot;
	}
	
	
	
	
	/*
	 * RICERCA DI UN elemento dell'albero con la MOSSA definita in "searchForBoard"
	 * la ricerca parte dal NodoLista passato
	 * La condizione "&& this.getEleListaTrovato() == null" negli IF serve ad interrompere
	 * la ricerca quando l'elemento è stato trovato.
	 */
	private eleLista eleTrovato = null;
	
	public void searchDFS(Lista NodoL, eleLista eleL, int[][] searchForBoard) {
		this.setEleListaTrovato(null);//resetta eventuale ricerca precedente
		if(eleL.equalsBoard(searchForBoard)) {
			this.setEleListaTrovato(eleL);
			//System.exit(0);
			return;
		}
		
		if(eleL.getNodoListaSucc() != null && this.getEleListaTrovato() == null) {
			searchDFS(eleL.getNodoListaSucc(),eleL.getNodoListaSucc().getFirstEleL(),searchForBoard);
		}
		
		if(eleL.getEleSuccL() != null && this.getEleListaTrovato() == null) {
			searchDFS(NodoL,eleL.getEleSuccL(),searchForBoard);
		}
	}
	
	public void setEleListaTrovato(eleLista eleTrovato) {
		this.eleTrovato = eleTrovato;
	}
	
	public eleLista getEleListaTrovato() {
		return this.eleTrovato;
	}
	 
	//*****************************************************************************
	/*
	 * VERIFICA SE LA BOARD E' IN UNO STATO DI VITTORIA
	 */
	
	public boolean checkWinner(int[][] statoBoard) {
		if(statoBoard[0][0] != -1 && statoBoard[0][0] == statoBoard[1][1] && statoBoard[0][0] == statoBoard[2][2]){
			//System.out.println("The winner is ... diagonale da sx a dx");
			return true;
		}else if(statoBoard[0][0] != -1 && statoBoard[0][0]==statoBoard[0][1] && statoBoard[0][0]==statoBoard[0][2]) {
			//System.out.println("The winner is ... 1^ riga");
			return true;
		}else if(statoBoard[1][0] != -1 && statoBoard[1][0]==statoBoard[1][1] && statoBoard[1][0]==statoBoard[1][2]) {
			//System.out.println("The winner is ... 2^ riga");
			return true;
		}else if(statoBoard[2][0] != -1 && statoBoard[2][0]==statoBoard[2][1] && statoBoard[2][0]==statoBoard[2][2]) {
			//System.out.println("The winner is ... 3^ riga");
			return true;
		}else if(statoBoard[0][2] != -1 && statoBoard[0][2]==statoBoard[1][1] && statoBoard[0][2]==statoBoard[2][0]) {
			//System.out.println("The winner is ... diagonale da dx a sx");
			return true;
		}else if(statoBoard[0][0] != -1 && statoBoard[0][0]==statoBoard[1][0] && statoBoard[0][0]==statoBoard[2][0]) {
			//System.out.println("The winner is ... 1^ colonna");
			return true;
		}else if(statoBoard[0][1] != -1 && statoBoard[0][1]==statoBoard[1][1] && statoBoard[0][1]==statoBoard[2][1]) {
			//System.out.println("The winner is ... 2^ colonna");
			return true;
		}else if(statoBoard[0][2] != -1 && statoBoard[0][2]==statoBoard[1][2] && statoBoard[0][2]==statoBoard[2][2]) {
			//System.out.println("The winner is ... 3^ colonna");
			return true;
		}		   
		
		return false;
	}	

}
