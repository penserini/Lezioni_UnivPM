import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class MainGUI extends JFrame {

	private JPanel contentPane;
	private JTextField text11;
	private JTextField text12;
	private JTextField text13;
	private JTextField text21;
	private JTextField text22;
	private JTextField text23;
	private JTextField text31;
	private JTextField text32;
	private JTextField text33;
	static MainGUI frame;
		
	private boolean startGame = false;
	private int[][] currentBoardState = new int[3][3];
	private String symbolPlayer1 = "O";
	private String symbolPlayer2 = "X";
	private int player_2 = 1;
	private boolean gameOver = false;
	private String finalStatus = "";
	
	public JLabel Lable_statoScacchiera;
	
	//private PlayerAI X_AI;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//MainGUI frame = new MainGUI();
					frame = new MainGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private boolean isGameOver() {
		return this.gameOver;
	}

	/*
	 * Questo metodo serve ad aggiornare la GUI della Scacchiera
	 */
	private void updateVisualBoard(int[] giocataAI) {
		if(giocataAI[0] == 0 && giocataAI[1] == 0){
			text11.setText(symbolPlayer2);
		}else if(giocataAI[0] == 0 && giocataAI[1] == 1) {
			text12.setText(symbolPlayer2);
		}else if(giocataAI[0] == 0 && giocataAI[1] == 2) {
			text13.setText(symbolPlayer2);
		}else if(giocataAI[0] == 1 && giocataAI[1] == 0) {
			text21.setText(symbolPlayer2);
		}else if(giocataAI[0] == 1 && giocataAI[1] == 1) {
			text22.setText(symbolPlayer2);
		}else if(giocataAI[0] == 1 && giocataAI[1] == 2) {
			text23.setText(symbolPlayer2);
		}else if(giocataAI[0] == 2 && giocataAI[1] == 0) {
			text31.setText(symbolPlayer2);
		}else if(giocataAI[0] == 2 && giocataAI[1] == 1) {
			text32.setText(symbolPlayer2);
		}else if(giocataAI[0] == 2 && giocataAI[1] == 2) {
			text33.setText(symbolPlayer2);
		}		
	}
	
	/*
	 * "fineGioco" restituisce true quando viene intercettata una vittoria
	 */
	public boolean fineGioco(int[][] statoBoard) {
		//System.out.println(" DENTRO fineGioco ");
		//Lable_statoScacchiera.setText(" DENTRO fineGioco ");
		
		if(statoBoard[0][0] != -1 && statoBoard[0][0] == statoBoard[1][1] && statoBoard[0][0] == statoBoard[2][2]){
			//System.out.println("The winner is ... diagonale da sx a dx");
			if(this.text11.getText().equals("X")) {
				this.finalStatus = "The WINNER is Player X - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}else if(this.text11.getText().equals("O")) {
				this.finalStatus = "The WINNER is Player O - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}
			this.gameOver = true;			
			return true;
		}else if(statoBoard[0][0] != -1 && statoBoard[0][0]==statoBoard[0][1] && statoBoard[0][0]==statoBoard[0][2]) {
			//System.out.println("The winner is ... 1^ riga");
			if(this.text11.getText().equals("X")) {
				this.finalStatus = "The WINNER is Player X - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}else if(this.text11.getText().equals("O")) {
				this.finalStatus = "The WINNER is Player O - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}
			this.gameOver = true;
			return true;
		}else if(statoBoard[1][0] != -1 && statoBoard[1][0]==statoBoard[1][1] && statoBoard[1][0]==statoBoard[1][2]) {
			//System.out.println("The winner is ... 2^ riga");
			if(this.text21.getText().equals("X")) {
				this.finalStatus = "The WINNER is Player X - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}else if(this.text21.getText().equals("O")) {
				this.finalStatus = "The WINNER is Player O - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}
			this.gameOver = true;
			return true;
		}else if(statoBoard[2][0] != -1 && statoBoard[2][0]==statoBoard[2][1] && statoBoard[2][0]==statoBoard[2][2]) {
			//System.out.println("The winner is ... 3^ riga");
			if(this.text31.getText().equals("X")) {
				this.finalStatus = "The WINNER is Player X - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}else if(this.text31.getText().equals("O")) {
				this.finalStatus = "The WINNER is Player O - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}
			this.gameOver = true;
			return true;
		}else if(statoBoard[0][2] != -1 && statoBoard[0][2]==statoBoard[1][1] && statoBoard[0][2]==statoBoard[2][0]) {
			//System.out.println("The winner is ... diagonale da dx a sx");
			if(this.text13.getText().equals("X")) {
				//System.out.println(" ******** DENTRO fineGioco ******** ");
				this.finalStatus = "The WINNER is Player X - GAME OVER!";
				Lable_statoScacchiera.setText("The WINNER is Player X - GAME OVER!");
			}else if(this.text13.getText().equals("O")) {
				this.finalStatus = "The WINNER is Player O - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}
			this.gameOver = true;
			return true;
		}else if(statoBoard[0][0] != -1 && statoBoard[0][0]==statoBoard[1][0] && statoBoard[0][0]==statoBoard[2][0]) {
			//System.out.println("The winner is ... 1^ colonna");
			if(this.text11.getText().equals("X")) {
				this.finalStatus = "The WINNER is Player X - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}else if(this.text11.getText().equals("O")) {
				this.finalStatus = "The WINNER is Player O - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}
			this.gameOver = true;
			return true;
		}else if(statoBoard[0][1] != -1 && statoBoard[0][1]==statoBoard[1][1] && statoBoard[0][1]==statoBoard[2][1]) {
			//System.out.println("The winner is ... 2^ colonna");
			if(this.text12.getText().equals("X")) {
				this.finalStatus = "The WINNER is Player X - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}else if(this.text12.getText().equals("O")) {
				this.finalStatus = "The WINNER is Player O - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}
			this.gameOver = true;
			return true;
		}else if(statoBoard[0][2] != -1 && statoBoard[0][2]==statoBoard[1][2] && statoBoard[0][2]==statoBoard[2][2]) {
			//System.out.println("The winner is ... 3^ colonna");
			if(this.text13.getText().equals("X")) {
				this.finalStatus = "The WINNER is Player X - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}else if(this.text13.getText().equals("O")) {
				this.finalStatus = "The WINNER is Player O - GAME OVER!";
				Lable_statoScacchiera.setText(this.finalStatus);
			}
			this.gameOver = true;
			return true;
		}		   
		
		return false;
	}	
	
	private void setGameStart(boolean val) {
		this.startGame = val;
	}
	
	/*
	 * Configuro la scacchiera ad avere tutte le celle a -1 cioè vuote
	 */
	private void setCurrentBoard() {
	     for (int r = 0; r < this.currentBoardState.length; r++) {
	         for (int c = 0; c < this.currentBoardState.length; c++) {
	        	 this.currentBoardState[r][c] = -1;
	         }
	     }
	}
	
	
	private boolean boardFull(int[][] Board) {		
	     for (int r = 0; r < Board.length; r++) {
	         for (int c = 0; c < Board.length; c++) {
	        	 
	        	 if(Board[r][c] == -1) {
	        		 return false;	
	        	 }
	         }
	     }
		this.finalStatus = "TIE BREAK - GAME OVER!";
		this.gameOver = true;
		Lable_statoScacchiera.setText(this.finalStatus);
	     
		return true;
	}
	
	/*
	 * Metodo che aggiorna lo stato della scacchiera mossa dopo mossa
	 */
	private void setBoardMove(int rig, int col, String symbolPlayer) {
		if(symbolPlayer.equals("O")) {
			this.currentBoardState[rig][col] = 0;
		}else if(symbolPlayer.equals("X")) {
			this.currentBoardState[rig][col] = 1;
		}		
	}
	
	
	private int[][] getCurrentBoard() {
		return this.currentBoardState;	
	}
	
	
	/**
	 * Create the frame.
	 */
	public MainGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 507, 362);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		/*
		 * BOARD with labels
		 */
		JLabel lblNewLabel = new JLabel("|");
		lblNewLabel.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel.setBounds(314, 33, 14, 38);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("|");
		lblNewLabel_1.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(314, 59, 14, 38);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("|");
		lblNewLabel_1_1.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1_1.setBounds(314, 86, 14, 38);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("|");
		lblNewLabel_2.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_2.setBounds(314, 113, 14, 38);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_2 = new JLabel("|");
		lblNewLabel_1_2.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1_2.setBounds(314, 139, 14, 38);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("|");
		lblNewLabel_1_1_1.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1_1_1.setBounds(314, 166, 14, 38);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_3 = new JLabel("_____________");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_3.setBounds(224, 79, 279, 53);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("|");
		lblNewLabel_4.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_4.setBounds(394, 33, 14, 38);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_1_3 = new JLabel("|");
		lblNewLabel_1_3.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1_3.setBounds(394, 59, 14, 38);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("|");
		lblNewLabel_1_1_2.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1_1_2.setBounds(394, 86, 14, 38);
		contentPane.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("|");
		lblNewLabel_2_1.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_2_1.setBounds(394, 113, 14, 38);
		contentPane.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("|");
		lblNewLabel_1_2_1.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1_2_1.setBounds(394, 139, 14, 38);
		contentPane.add(lblNewLabel_1_2_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("|");
		lblNewLabel_1_1_1_1.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1_1_1_1.setBounds(394, 166, 14, 38);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_2 = new JLabel("|");
		lblNewLabel_1_1_1_2.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1_1_1_2.setBounds(314, 248, 14, 38);
		contentPane.add(lblNewLabel_1_1_1_2);
		
		JLabel lblNewLabel_1_2_2 = new JLabel("|");
		lblNewLabel_1_2_2.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1_2_2.setBounds(314, 221, 14, 38);
		contentPane.add(lblNewLabel_1_2_2);
		
		JLabel lblNewLabel_2_2 = new JLabel("|");
		lblNewLabel_2_2.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_2_2.setBounds(314, 195, 14, 38);
		contentPane.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("|");
		lblNewLabel_2_1_1.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_2_1_1.setBounds(394, 195, 14, 38);
		contentPane.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_1_2_1_1 = new JLabel("|");
		lblNewLabel_1_2_1_1.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1_2_1_1.setBounds(394, 221, 14, 38);
		contentPane.add(lblNewLabel_1_2_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("|");
		lblNewLabel_1_1_1_1_1.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_1_1_1_1_1.setBounds(394, 248, 14, 38);
		contentPane.add(lblNewLabel_1_1_1_1_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("_____________");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1.setFont(new Font("Verdana", Font.PLAIN, 30));
		lblNewLabel_3_1.setBounds(224, 158, 279, 53);
		contentPane.add(lblNewLabel_3_1);
		
		//Inizializza le celle della scacchiera a -1
		this.setCurrentBoard();
		
		text11 = new JTextField();
		text11.setEditable(false);
		text11.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(startGame==true) {					
					text11.setFont(new Font("Verdana", Font.PLAIN, 40));
					text11.setText(symbolPlayer1);
					setBoardMove(0, 0, symbolPlayer1);
					startGame=false;//inibisce la scacchiera per il player-1
					
					/*
					 * Controlla se dopo la mossa di Player-1
					 * si è generata una vittoria o una patta
					 */
					if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
						//MOSSA PER IL PLAYER-2 con AI					
						PlayerAI X_AI = new PlayerAI(getCurrentBoard(),player_2);
						int[] coordGiocata = new int[2];
						coordGiocata = X_AI.getGiocataAI();
						setBoardMove(coordGiocata[0], coordGiocata[1], symbolPlayer2);
						updateVisualBoard(coordGiocata);
						
						/*
						 * Controlla se dopo la mossa di di AI (Player-2)
						 * si è generata una vittoria o una patta
						 */
						if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
							//System.exit(0);
							startGame=true;
							return;//si attende la prossima mossa di Player-1
						}else {
							return;
						}
						
					}else {
						//System.exit(0);
						return;
					}
				}
			}
		});
		text11.setHorizontalAlignment(SwingConstants.CENTER);
		text11.setFont(new Font("Verdana", Font.PLAIN, 40));
		text11.setBounds(257, 59, 47, 46);
		contentPane.add(text11);
		text11.setColumns(10);
		
		text12 = new JTextField();
		text12.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(startGame==true) {
					text12.setFont(new Font("Verdana", Font.PLAIN, 40));
					text12.setText(symbolPlayer1);
					setBoardMove(0, 1, symbolPlayer1);
					startGame=false;
					
					/*
					 * Controlla se dopo la mossa di Player-1
					 * si è generata una vittoria o una patta
					 */
					if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
						//MOSSA PER IL PLAYER-2 con AI					
						PlayerAI X_AI = new PlayerAI(getCurrentBoard(),player_2);
						int[] coordGiocata = new int[2];
						coordGiocata = X_AI.getGiocataAI();
						setBoardMove(coordGiocata[0], coordGiocata[1], symbolPlayer2);
						updateVisualBoard(coordGiocata);
						
						/*
						 * Controlla se dopo la mossa di di AI (Player-2)
						 * si è generata una vittoria o una patta
						 */
						if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
							//System.exit(0);
							startGame=true;
							return;//si attende la prossima mossa di Player-1
						}else {
							return;
						}
						
					}else {
						//System.exit(0);
						return;
					}
				}
			}
		});
		text12.setEditable(false);
		text12.setHorizontalAlignment(SwingConstants.CENTER);
		text12.setFont(new Font("Verdana", Font.PLAIN, 40));
		text12.setColumns(10);
		text12.setBounds(337, 59, 47, 46);
		contentPane.add(text12);
		
		text13 = new JTextField();
		text13.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(startGame==true) {
					text13.setFont(new Font("Verdana", Font.PLAIN, 40));
					text13.setText(symbolPlayer1);
					setBoardMove(0, 2, symbolPlayer1);
					startGame=false;
					
					/*
					 * Controlla se dopo la mossa di Player-1
					 * si è generata una vittoria o una patta
					 */
					if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
						//MOSSA PER IL PLAYER-2 con AI					
						PlayerAI X_AI = new PlayerAI(getCurrentBoard(),player_2);
						int[] coordGiocata = new int[2];
						coordGiocata = X_AI.getGiocataAI();
						setBoardMove(coordGiocata[0], coordGiocata[1], symbolPlayer2);
						updateVisualBoard(coordGiocata);
						
						/*
						 * Controlla se dopo la mossa di di AI (Player-2)
						 * si è generata una vittoria o una patta
						 */
						if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
							//System.exit(0);
							startGame=true;
							return;//si attende la prossima mossa di Player-1
						}else {
							return;
						}
						
					}else {
						//System.exit(0);
						return;
					}
				}
			}
		});
		text13.setEditable(false);
		text13.setHorizontalAlignment(SwingConstants.CENTER);
		text13.setFont(new Font("Verdana", Font.PLAIN, 40));
		text13.setColumns(10);
		text13.setBounds(420, 59, 47, 46);
		contentPane.add(text13);
		
		text21 = new JTextField();
		text21.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(startGame==true) {
					text21.setFont(new Font("Verdana", Font.PLAIN, 40));
					text21.setText(symbolPlayer1);
					setBoardMove(1, 0, symbolPlayer1);
					startGame=false;
					
					/*
					 * Controlla se dopo la mossa di Player-1
					 * si è generata una vittoria o una patta
					 */
					if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
						//MOSSA PER IL PLAYER-2 con AI					
						PlayerAI X_AI = new PlayerAI(getCurrentBoard(),player_2);
						int[] coordGiocata = new int[2];
						coordGiocata = X_AI.getGiocataAI();
						setBoardMove(coordGiocata[0], coordGiocata[1], symbolPlayer2);
						updateVisualBoard(coordGiocata);
						
						/*
						 * Controlla se dopo la mossa di di AI (Player-2)
						 * si è generata una vittoria o una patta
						 */
						if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
							//System.exit(0);
							startGame=true;
							return;//si attende la prossima mossa di Player-1
						}else {
							return;
						}
						
					}else {
						//System.exit(0);
						return;
					}
				}
			}
		});
		text21.setEditable(false);
		text21.setHorizontalAlignment(SwingConstants.CENTER);
		text21.setFont(new Font("Verdana", Font.PLAIN, 40));
		text21.setColumns(10);
		text21.setBounds(257, 139, 47, 46);
		contentPane.add(text21);
		
		text22 = new JTextField();
		text22.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(startGame==true) {
					text22.setFont(new Font("Verdana", Font.PLAIN, 40));
					text22.setText(symbolPlayer1);
					setBoardMove(1, 1, symbolPlayer1);
					startGame=false;
					
					/*
					 * Controlla se dopo la mossa di Player-1
					 * si è generata una vittoria o una patta
					 */
					if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
						//MOSSA PER IL PLAYER-2 con AI					
						PlayerAI X_AI = new PlayerAI(getCurrentBoard(),player_2);
						int[] coordGiocata = new int[2];
						coordGiocata = X_AI.getGiocataAI();
						setBoardMove(coordGiocata[0], coordGiocata[1], symbolPlayer2);
						updateVisualBoard(coordGiocata);
						
						/*
						 * Controlla se dopo la mossa di di AI (Player-2)
						 * si è generata una vittoria o una patta
						 */
						if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
							//System.exit(0);
							startGame=true;
							return;//si attende la prossima mossa di Player-1
						}else {
							return;
						}
						
					}else {
						//System.exit(0);
						return;
					}
				}
			}
		});
		text22.setEditable(false);
		text22.setHorizontalAlignment(SwingConstants.CENTER);
		text22.setFont(new Font("Verdana", Font.PLAIN, 40));
		text22.setColumns(10);
		text22.setBounds(337, 139, 47, 46);
		contentPane.add(text22);
		
		text23 = new JTextField();
		text23.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(startGame==true) {
					text23.setFont(new Font("Verdana", Font.PLAIN, 40));
					text23.setText(symbolPlayer1);
					setBoardMove(1, 2, symbolPlayer1);
					startGame=false;
					
					/*
					 * Controlla se dopo la mossa di Player-1
					 * si è generata una vittoria o una patta
					 */
					if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
						//MOSSA PER IL PLAYER-2 con AI					
						PlayerAI X_AI = new PlayerAI(getCurrentBoard(),player_2);
						int[] coordGiocata = new int[2];
						coordGiocata = X_AI.getGiocataAI();
						setBoardMove(coordGiocata[0], coordGiocata[1], symbolPlayer2);
						updateVisualBoard(coordGiocata);
						
						/*
						 * Controlla se dopo la mossa di di AI (Player-2)
						 * si è generata una vittoria o una patta
						 */
						if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
							//System.exit(0);
							startGame=true;
							return;//si attende la prossima mossa di Player-1
						}else {
							return;
						}
						
					}else {
						//System.exit(0);
						return;
					}
				}
			}
		});
		text23.setEditable(false);
		text23.setHorizontalAlignment(SwingConstants.CENTER);
		text23.setFont(new Font("Verdana", Font.PLAIN, 40));
		text23.setColumns(10);
		text23.setBounds(420, 139, 47, 46);
		contentPane.add(text23);
		
		text31 = new JTextField();
		text31.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(startGame==true) {
					text31.setFont(new Font("Verdana", Font.PLAIN, 40));
					text31.setText(symbolPlayer1);
					setBoardMove(2, 0, symbolPlayer1);
					startGame=false;
					
					/*
					 * Controlla se dopo la mossa di Player-1
					 * si è generata una vittoria o una patta
					 */
					if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
						//MOSSA PER IL PLAYER-2 con AI					
						PlayerAI X_AI = new PlayerAI(getCurrentBoard(),player_2);
						int[] coordGiocata = new int[2];
						coordGiocata = X_AI.getGiocataAI();
						setBoardMove(coordGiocata[0], coordGiocata[1], symbolPlayer2);
						updateVisualBoard(coordGiocata);
						
						/*
						 * Controlla se dopo la mossa di di AI (Player-2)
						 * si è generata una vittoria o una patta
						 */
						if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
							//System.exit(0);
							startGame=true;
							return;//si attende la prossima mossa di Player-1
						}else {
							return;
						}
						
					}else {
						//System.exit(0);
						return;
					}
				}
			}
		});
		text31.setEditable(false);
		text31.setHorizontalAlignment(SwingConstants.CENTER);
		text31.setFont(new Font("Verdana", Font.PLAIN, 40));
		text31.setColumns(10);
		text31.setBounds(257, 221, 47, 46);
		contentPane.add(text31);
		
		text32 = new JTextField();
		text32.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(startGame==true) {
					text32.setFont(new Font("Verdana", Font.PLAIN, 40));
					text32.setText(symbolPlayer1);
					setBoardMove(2, 1, symbolPlayer1);
					startGame=false;
					
					/*
					 * Controlla se dopo la mossa di Player-1
					 * si è generata una vittoria o una patta
					 */
					if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
						//MOSSA PER IL PLAYER-2 con AI					
						PlayerAI X_AI = new PlayerAI(getCurrentBoard(),player_2);
						int[] coordGiocata = new int[2];
						coordGiocata = X_AI.getGiocataAI();
						setBoardMove(coordGiocata[0], coordGiocata[1], symbolPlayer2);
						updateVisualBoard(coordGiocata);
						
						/*
						 * Controlla se dopo la mossa di di AI (Player-2)
						 * si è generata una vittoria o una patta
						 */
						if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
							//System.exit(0);
							startGame=true;
							return;//si attende la prossima mossa di Player-1
						}else {
							return;
						}
						
					}else {
						//System.exit(0);
						return;
					}
				}
			}
		});
		text32.setEditable(false);
		text32.setHorizontalAlignment(SwingConstants.CENTER);
		text32.setFont(new Font("Verdana", Font.PLAIN, 40));
		text32.setColumns(10);
		text32.setBounds(337, 221, 47, 46);
		contentPane.add(text32);
		
		text33 = new JTextField();
		text33.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(startGame==true) {
					text33.setFont(new Font("Verdana", Font.PLAIN, 40));
					text33.setText(symbolPlayer1);
					setBoardMove(2, 2, symbolPlayer1);
					startGame=false;
					
					/*
					 * Controlla se dopo la mossa di Player-1
					 * si è generata una vittoria o una patta
					 */
					if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
						//MOSSA PER IL PLAYER-2 con AI					
						PlayerAI X_AI = new PlayerAI(getCurrentBoard(),player_2);
						int[] coordGiocata = new int[2];
						coordGiocata = X_AI.getGiocataAI();
						setBoardMove(coordGiocata[0], coordGiocata[1], symbolPlayer2);
						updateVisualBoard(coordGiocata);
						
						/*
						 * Controlla se dopo la mossa di di AI (Player-2)
						 * si è generata una vittoria o una patta
						 */
						if(!fineGioco(getCurrentBoard()) && !boardFull(getCurrentBoard())) {
							//System.exit(0);
							startGame=true;
							return;//si attende la prossima mossa di Player-1
						}else {
							return;
						}
						
					}else {
						//System.exit(0);
						return;
					}
				}
			}
		});
		text33.setEditable(false);
		text33.setHorizontalAlignment(SwingConstants.CENTER);
		text33.setFont(new Font("Verdana", Font.PLAIN, 40));
		text33.setColumns(10);
		text33.setBounds(420, 221, 47, 46);
		contentPane.add(text33);
		
		JButton Gioca = new JButton("GIOCA");
		Gioca.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isGameOver()) {
					setGameStart(true);
					Lable_statoScacchiera.setText("Partita in corso...");
				}else {
					frame.dispose();
					EventQueue.invokeLater(new Runnable() {
						public void run() {
							try {
								//MainGUI frame = new MainGUI();
								frame = new MainGUI();
								frame.setVisible(true);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					});
				}				
			}
		});
		Gioca.setFont(new Font("Verdana", Font.PLAIN, 20));
		Gioca.setBounds(23, 143, 102, 38);
		contentPane.add(Gioca);
		
		JLabel Lable_Title = new JLabel("GIOCARE CONTRO AI");
		Lable_Title.setHorizontalAlignment(SwingConstants.CENTER);
		Lable_Title.setFont(new Font("Verdana", Font.BOLD, 16));
		Lable_Title.setBounds(126, 10, 250, 28);
		contentPane.add(Lable_Title);
		
		Lable_statoScacchiera = new JLabel("Clicca \"GIOCA\" per iniziare");
		Lable_statoScacchiera.setHorizontalAlignment(SwingConstants.CENTER);
		Lable_statoScacchiera.setForeground(new Color(255, 0, 0));
		Lable_statoScacchiera.setFont(new Font("Verdana", Font.BOLD, 12));
		Lable_statoScacchiera.setBounds(109, 296, 307, 27);
		contentPane.add(Lable_statoScacchiera);
	}
}
