/**
*
* @author  
* @version 
* N.B. Lo stato della scacchiera è il medesimo per tutti gli elementi della Lista
*/
import java.util.Vector;

public class Lista {
	private Lista nodoListaPrec = null;
	private eleLista currentEleLista = null;
	private eleLista eleTestaLista = null;
	private eleLista primoEleLista = null;
	private Vector<int[][]> vectMosseFatte = new Vector<int[][]>();//contiene le board/mosse di eleL già create
	private int[][] MosseFatte = null;
	
	
	/*
	 * Creao una Lista con il primo elemento iniziale e la sua Board
	 */
	public Lista(int[][] statoBoard) {
		currentEleLista = new eleLista(statoBoard,this, true);//"true" solo per il primo elemento
		this.primoEleLista = currentEleLista;
		currentEleLista.setPrecL(null);
		currentEleLista.setSuccL(null);
		//this.eleTestaLista = currentEleLista;//si associa ad ogni nuova lista un elemento "testa"
	}
	
	
	/* ************************************************************************
	 * Aggiunge un elemento (newElementoLista) e "current" si sposta su quel nuovo elemento
	 */
	public void addElementoLista(eleLista newElementoLista) {//deprecated
		currentEleLista.setSuccL(newElementoLista);
		newElementoLista.setPrecL(currentEleLista);
		newElementoLista.setSuccL(null);
		
		this.setCurrent(newElementoLista);
	}
	
	public void addElLista(eleLista newElementoLista) {//new method
		//eleLista eleL = this.getEleTestaLista();
		eleLista eleL = this.getFirstEleL();
		while(eleL.getEleSuccL() != null) {
			eleL = eleL.getEleSuccL();
		}
		
		eleL.setSuccL(newElementoLista);
		newElementoLista.setPrecL(eleL);
		newElementoLista.setSuccL(null);
		
		this.setCurrent(newElementoLista);
	}
	//*************************************************************************
	
	
	/*
	 * Aggiungere Liste come nodi dell'albero: NodoLista
	 */
	public void addNodoLista(Lista newNodoLista) {
		newNodoLista.nodoListaPrec = this;		
	}
	
	public void addMossaBoard(int[][] newBoard) {
		this.vectMosseFatte.addElement(newBoard);
	}
	
	
	public void setCurrent(eleLista newElementoLista) {
		this.currentEleLista = newElementoLista;
	}
	
	/*
	 * n.b. un nodo lista non può avere un nodo successivo, poiché in questa struttura di albero ne ha MOLTI.
	 * Per cui è l'elemnto del nodoLista che ha il puntatore al nodoLista successivo.
	 */
	public void setNodoListaSucc(Lista newNodoLista) {
		this.currentEleLista.setNodoListaSucc(newNodoLista);//n.b. si chiamano uguali ma sono su classi diverse 
	}

	public void setEleTestaLista(eleLista eleTestaLista) {
		this.eleTestaLista = eleTestaLista;
	}
	
	/*
	 * GET's
	 */
	
	public eleLista getEleTestaLista() {
		return this.eleTestaLista;
	}
	
	public eleLista getFirstEleL() {		
		//return this.eleTestaLista;
		return this.primoEleLista;
	}
	
	
	public int[][] getMosseFatte() {
		return this.MosseFatte;		
	}
	
	public int getSizeVectMosseFatte() {
		return this.vectMosseFatte.size();
	}
	
	public Vector<int[][]> getVectMosseFatte(){
		return this.vectMosseFatte;
	}
	
	//GENERIC METHODs
	
	public boolean EsisteMossa() {		
	    if(this.vectMosseFatte.size()>0) return true;
		return false;
	}
	

	public Lista getNodoListaPrec() {
		return this.nodoListaPrec;		
	}
	
	
	public eleLista getCurrentEleLista() {		
		return this.currentEleLista;
	}

}
