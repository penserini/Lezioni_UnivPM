import requests
import json

class AIChat(object):
    domanda = ""
    risposta = ""
    url = "http://localhost:11434/api/chat"  # Modifica se l'endpoint è diverso

    '''
    def __init__(self, query):
        self.domanda = query
        #self.domanda = "Cosa sai fare?"
        sendQuery()
    '''
    
    def AIconPersonalita(self,query):        
        self.domanda = query
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": "llama3.1", "prompt": self.domanda, "stream": False}
        )
        self.risposta = response.json()["response"].strip().lower()
        print(f"🤖 LLaMA ha risposto: {self.risposta}")
        return self.risposta

    def sendQuery(self, query):  
        self.domanda = query      
        # URL dell'API locale di Ollama
        #url = "http://localhost:11434/api/chat"  # Modifica se l'endpoint è diverso
        payload = {
            "model": "llama3.1",
            "messages": [{"role":"user", "content": self.domanda}]
        }

        try:
            response = requests.post(self.url, json=payload, stream=True)        
            response.raise_for_status()  # verifica errori di richieste

            if response.status_code == 200:
                print("Streaming response from Ollama:")
                for line in response.iter_lines(decode_unicode=True):
                    if line: #ignora le righe vuote
                        try:
                            #parse each line as a JSON object
                            json_data = json.loads(line)
                            # Extract and print the assistant's message content
                            if "message" in json_data and "content" in json_data["message"]:
                                #print(json_data["message"]["content"], end="") #stampa e non va a capo
                                self.risposta = self.risposta + json_data["message"]["content"]

                        except json.JSONDecodeError:
                            print(f"\nFailed to parse line:{line}")

                print(self.risposta)
                print() # Assicurati che l'output finisca con una nuova linea
        
        except requests.exceptions.RequestException as e:
            print("Errore durante la richiesta:", e)

    def getAI_answer(self):
        return self.risposta
    
    def getURL(self):
        return self.url


'''
#funzione principale
def main():
    app = AIChat()
    app.sendQuery("Cosa sai fare?")


main()
'''    