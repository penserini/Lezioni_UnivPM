import whisper
import requests
import os
import subprocess
import sounddevice as sd
from scipy.io.wavfile import write
import pyttsx3

class AIbaby(object):
    #testo = ""

    #@staticmethod
    def parla(testo):
        engine = pyttsx3.init()
        engine.say(testo)
        engine.runAndWait()

    # Funzione per registrare audio
    def registra_audio(file_name="audio.wav", durata=5, fs=16000):
        print("Registrazione in corso...")
        registrazione = sd.rec(int(durata * fs), samplerate=fs, channels=1, dtype='int16')
        sd.wait()
        write(file_name, fs, registrazione)
        print("Registrazione salvata.")

    # Funzione per trascrivere con Whisper
    def trascrivi_audio(file_name="audio.wav"):
        model = whisper.load_model("base")
        result = model.transcribe(file_name)
        print(f"Hai detto: {result['text']}")
        return result['text']

    # Funzione per inviare input a LLaMA (via Ollama REST API)
    def interpreta_testo(testo,kb_prompt):
        '''
        prompt = f"""
        L'utente ha detto: "{testo.strip()}".
        Qual è il comando da eseguire? Rispondi solo con una delle seguenti parole:
        'accendi', 'spegni', 'esci', 'niente'. Se l'utente vuole smettere, uscire, oppure
        terminare il programma, allora esegui il comando 'esci'. Se l'utente dice, accendi la luce? allora esegui 'accendi'.
        Se l'utente dice: spegni la luce, allora esegui 'spegni'.
        """
        '''
        prompt = f"""L'utente ha detto: "{testo.strip()}"."{kb_prompt.strip()}"."""
        print("*******",prompt)

        response = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": "llama3.1", "prompt": prompt, "stream": False}
        )
        risposta = response.json()["response"].strip().lower()
        print(f"🤖 LLaMA ha risposto: {risposta}")
        return risposta

    # Funzione per eseguire un'azione
    def esegui_azione(azione):
        azione = azione.replace("'",'')
        azione = azione.replace(".",'')
        # (loris) shelly_ip = "192.168.1.152"
        # ITS: shelly_ip = "192.168.1.152"
        shelly_ip = "10.100.112.21"
        if azione == "accendi" or azione == 'accendi':
            #print("Invio comando: accendi la luce")
            try:
                requests.get(f"http://{shelly_ip}/relay/0?turn=on", timeout=3)
                AIbaby.parla("Ho acceso la luce.")
            except:
                AIbaby.parla("Errore: non riesco a raggiungere la presa.")        
        elif azione == "spegni" or azione == 'spegni':
            #print("Invio comando: spegni la luce")
            try:
                requests.get(f"http://{shelly_ip}/relay/0?turn=off", timeout=3)
                AIbaby.parla("Ho spento la luce.")
            except:
                AIbaby.parla("Errore: non riesco a raggiungere la presa.")        
        elif azione == "esci" or azione == 'esci':
            print("👋 Richiesta di uscire.")
            AIbaby.parla("Arrivederci!")
        else:
            print("🤷‍♂️ Nessuna azione riconosciuta.")
            AIbaby.parla("Non ho capito il comando.")

# === FLUSSO PRINCIPALE ===
if __name__ == "__main__":
    while True:
        app = AIbaby
        app.registra_audio()
        testo = app.trascrivi_audio()
        azione = app.interpreta_testo(testo)
        azione = azione.replace("'",'')
        azione = azione.replace(".",'')
        if azione == "esci" or azione == 'esci':
            break
        
        app.esegui_azione(azione)
