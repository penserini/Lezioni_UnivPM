# Esempio che utilizza il client ufficiale di Ollama (e non il server web Ollama)
from __future__ import annotations
from typing import Callable, Dict, List, Optional
import ollama

Message = Dict[str, str]  # {"role": "system"|"user"|"assistant", "content": "..."}


class OllamaClient:
    """
    Wrapper class-based per Ollama:
      - generate(): prompt singolo (completion-style)
      - chat(): conversazione completa (chat-style)
      - say(): aggiunge turno utente allo storico e risponde
      - system(): imposta/aggiorna il messaggio di sistema
    Supporta: streaming, callback on_chunk, storico conversazione, opzioni extra.
    """

    def __init__(self, model: str = "llama3.1", system_prompt: Optional[str] = None):
        self.model = model
        self.history: List[Message] = []
        if system_prompt:
            self.history.append({"role": "system", "content": system_prompt})
        self.last_text: str = ""

    # ---- utility ----
    def set_model(self, model: str) -> None:
        self.model = model

    def reset(self, keep_system: bool = True) -> None:
        """Svuota lo storico (opzionalmente mantiene il messaggio di sistema)."""
        if keep_system:
            self.history = [m for m in self.history if m["role"] == "system"]
        else:
            self.history = []
        self.last_text = ""

    def system(self, content: str) -> None:
        """Imposta/aggiorna il messaggio di sistema in testa allo storico."""
        for m in self.history:
            if m["role"] == "system":
                m["content"] = content
                break
        else:
            self.history.insert(0, {"role": "system", "content": content})

    # ---- prompt singolo ----
    def generate(
        self,
        prompt: str,
        *,
        stream: bool = True,
        on_chunk: Optional[Callable[[str], None]] = None,
        **kwargs
    ) -> str:
        """
        Genera testo da prompt singolo via ollama.generate.
        stream=True → emette chunk via on_chunk e ritorna il testo completo.
        kwargs → inoltrati a ollama.generate (es. options={"temperature": 0.3}).
        """
        self.last_text = ""
        
        if not stream: # Se l’utente NON vuole streaming: si fa una sola chiamata (senza chunk).
            resp = ollama.generate(model=self.model, prompt=prompt, stream=False, **kwargs)
            self.last_text = resp.get("response", "")
            return self.last_text

        chunks: List[str] = []
        for part in ollama.generate(model=self.model, prompt=prompt, stream=True, **kwargs):
            txt = part.get("response", "")
            if txt:
                if on_chunk:
                    on_chunk(txt)
                chunks.append(txt)
            if part.get("done") is True:
                break

        self.last_text = "".join(chunks)
        return self.last_text

    # ---- chat multi-turno ----
    def chat(
        self,
        messages: Optional[List[Message]] = None,
        *,
        stream: bool = True,
        on_chunk: Optional[Callable[[str], None]] = None,
        **kwargs
    ) -> str:
        """
        Invia una conversazione a ollama.chat.
        Se messages è None, usa self.history.
        stream=True → emette chunk via on_chunk e ritorna il testo completo.
        kwargs → inoltrati a ollama.chat.
        """
        self.last_text = ""
        msg_list = messages if messages is not None else self.history

        if not stream:
            resp = ollama.chat(model=self.model, messages=msg_list, stream=False, **kwargs)
            text = resp.get("message", {}).get("content", "")
            self.last_text = text
            return text

        chunks: List[str] = []
        for part in ollama.chat(model=self.model, messages=msg_list, stream=True, **kwargs):
            msg = part.get("message", {})
            txt = msg.get("content", "")
            if txt:
                if on_chunk: # esegue la callback "on_chunk(txt)" solo se è stata fornita (not None)
                    on_chunk(txt)
                chunks.append(txt)
            if part.get("done") is True:
                break

        self.last_text = "".join(chunks)
        return self.last_text

    # ---- helper per ciclo chat ----
    def say(
        self,
        user_text: str,
        *,
        stream: bool = True,
        on_chunk: Optional[Callable[[str], None]] = None,
        **kwargs
    ) -> str:
        """
        Aggiunge un turno utente allo storico, ottiene la risposta assistant
        (streaming opzionale) e appende la risposta allo storico.
        """
        self.history.append({"role": "user", "content": user_text})
        reply_text = self.chat(stream=stream, on_chunk=on_chunk, **kwargs)
        self.history.append({"role": "assistant", "content": reply_text})
        return reply_text


# --- Esempi rapidi ---
if __name__ == "__main__":
    cli = OllamaClient(model="llama3.1", system_prompt="Rispondi in italiano e brevemente.")
    # Prompt singolo, no streaming
    print("== generate (no stream) ==")
    print(cli.generate("Cos'è il versioning semantico in 2 righe?", stream=False))

    # Chat con streaming
    print("\n== chat (stream) ==")
    def on_tok(t: str): print(t, end="", flush=True)
    cli.say("Dammi 3 vantaggi di /api/chat rispetto a /api/generate.", stream=True, on_chunk=on_tok)
    print("\n\n[STORICO] ->", cli.history[-2:])
